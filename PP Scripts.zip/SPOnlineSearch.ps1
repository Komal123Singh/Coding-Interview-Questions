 Connect-PnPOnline -URL "https://reactllearning800.sharepoint.com/sites/teams/" -UseWebLogin
# Example to get items from the Documents library
#Get-PnPListItem -List "Documents" | Where-Object { $_.File.Name -like "*Document*" }
$status = Get-PnPWeb -Includes NoCrawl
Write-Host "Current WEB status - Crawling: $(!$status.NoCrawl)"
# Define the search query
$listName = "Documents"

# Get the current status of the list
$list = Get-PnPList -Identity $listName -Includes NoCrawl
Write-Host "Current DOCUMENT LIBRARY ($($listName)) status - Crawling: $(!$list.NoCrawl)"

# # Disable Search Crawl on list
# #-------------------------------
# Set-PnPList -Identity $listName -NoCrawl

# $list = Get-PnPList -Identity $listName -Includes NoCrawl
# Write-Host "Current DOCUMENT LIBRARY ($($listName)) status - Crawling: $(!$list.NoCrawl)"

# # Enable Search Crawl on list
# #-------------------------------
# Set-PnPList -Identity $listName -NoCrawl:$false

# $list = Get-PnPList -Identity $listName -Includes NoCrawl
# Write-Host "Current DOCUMENT LIBRARY ($($listName)) status - Crawling: $(!$list.NoCrawl)" 



#  Connect-SPOService -url "https://reactllearning800-admin.sharepoint.com"
#   Get-SPOTenantRestrictedSearchMode
# List managed properties
#Get-SPOSearchManagedProperty



# #Set-SPOSite -Identity https://yourtenant.sharepoint.com/sites/yoursite -SearchDisabled $true  # Disable Search

# Set-SPOSite -Identity https://yourtenant.sharepoint.com/sites/yoursite -SearchDisabled $false # Enable Search

# Get-SPOSearchManagedProperty
