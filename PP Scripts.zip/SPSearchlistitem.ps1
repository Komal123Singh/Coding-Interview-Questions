Connect-PnPOnline -URL "https://reactllearning800.sharepoint.com/sites/teams/" -UseWebLogin

$list = "Product"   # Replace with your list name
$tosearch=Read-Host "Please enter Item"
$titleToSearch = $tosearch  # Replace with the title you are searching for

$items = Get-PnPListItem -List $list | Where-Object { $_.FieldValues["Title"] -eq $titleToSearch }

if ($items) {
    $items | ForEach-Object { Write-Host "Found Item: $($_.FieldValues['Title'])" }
} else {
    Write-Host "No items found with title '$titleToSearch'."
}
######################to get file using partial filename
$list = "Documents"  # Replace with your document library name
$partialNameToSearch = "*file handling*"  # Search for files that have 'Report' in their name

$items = Get-PnPListItem -List $list | Where-Object { $_.FieldValues["FileLeafRef"] -like $partialNameToSearch }

if ($items) {
    $items | ForEach-Object { Write-Host "Found File: $($_.FieldValues['FileLeafRef'])" }
} else {
    Write-Host "No files found matching '$partialNameToSearch'."
}


###get file url
if ($items) {
    $items | ForEach-Object {
        # Construct the full URL by combining the site URL with the relative file path
        $fileUrl = "https://reactllearning800.sharepoint.com" + $_.FieldValues["FileRef"]
        Write-Host "Found File: $($_.FieldValues['FileLeafRef'])"
        Write-Host "File URL: $fileUrl"
    }
} else {
    Write-Host "No files found matching '$partialNameToSearch'."
}
