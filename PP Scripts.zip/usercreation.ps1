﻿# Install the necessary PowerShell modules
#Install-Module -Name PnP.PowerShell -Force -Scope CurrentUser  # Install PnP PowerShell for SharePoint Online
#Import-Module -Name PnP.PowerShell
# Connect to SharePoint Online using an interactive login
#$siteUrl = "https://reactllearning800-admin.sharepoint.com"  # Replace with your SharePoint site URL
#Connect-SPOService -Url $siteUrl 
# Prompt for credentials (this opens a login window)
#$credentials = Get-Credential
Import-Module -Name ImportExcel
# Connect to the SharePoint Site using the provided credentials
Connect-PnPOnline -Url "https://reactllearning800.sharepoint.com/sites/teams/"  -UseWebLogin

 $dllPath = "C:\Windows\assembly\GAC_MSIL\Policy.11.0.Microsoft.Office.Interop.Excel\15.0.0.0__71e9bce111e9429c\Policy.11.0.Microsoft.Office.Interop.Excel.dll"
Add-Type -Path $dllPath
# Download the Excel file from the Document Library (assuming it is located in the "Documents" library)
#$excelFileUrl = "/sites/teams/Shared%20Documents/Forms/AllItems.aspx/TestUser/testUserCreation.xlsx"  # Path to the file in Document Library
$sheetName = "Sheet1"
$localFilePath = "C:\Users\ksingh318\OneDrive - DXC Production\Powershell\"
    # Define the folder and file names
$Existingfolderpath = "/sites/teams/TestFile/AutomateUserCreation"  # Correct server relative path to the folder
$Existingfilename = "testUserCreation.xlsx"  # The file you want to download

$serverRelativeUrl = "$Existingfolderpath/$Existingfilename"

# Download the Excel file from SharePoint to your local directory
Get-PnPFile -ServerRelativeUrl $serverRelativeUrl -Path $localFilePath -FileName $Existingfilename -AsFile


# Install the ImportExcel module if you don't have it installed
#Install-Module -Name ImportExcel -Force -Scope CurrentUser

# Import data from the Excel file
$filelocal="C:\Users\ksingh318\OneDrive - DXC Production\Powershell\$Existingfilename" 
  $data = Import-Excel -Path $filelocal
# Iterate over the Excel data and create users in SharePoint


foreach ($user in $data) {
    $userEmail = $user.Email
    $userName = $user.UserName
    $groupName = $user.GroupName

    # Check if the SharePoint group exists
    $group = Get-PnPGroup -Identity $groupName -ErrorAction SilentlyContinue
    if ($group) {
        # Add user to the SharePoint group
        try {
            Add-PnPUserToGroup -LoginName $userEmail -Identity $groupName
            Write-Host "Successfully added $userName ($userEmail) to the $groupName group."
        }
        catch {
            Write-Host "Failed to add $userName ($userEmail) to the $groupName group. Error: $_"
        }
    } else {
        Write-Host "Group $groupName does not exist. Skipping user creation for $userName ($userEmail)."
    }
}


# Disconnect from SharePoint Online
Disconnect-PnPOnline
