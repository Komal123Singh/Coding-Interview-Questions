
#purpose  Visit each document and listitem in a Site Collection and verify when this object was crawled
#Autor Kasper Larsen Fellowmind DK


$SiteCollectionUrl = "https://reactllearning800.sharepoint.com/sites/teams"
$tenantUrl ="https://reactllearning800.sharepoint.com"

Connect-PnPOnline -Url $SiteCollectionUrl -UseWebLogin
#if there are any subsites you will have to extend the script to handle that

$lists = Get-PnPList 
try
{
    foreach($list in $lists)
    {
        Write-Host "List Name" + $list.Title -ForegroundColor Blue
        $listItems = Get-PnPListItem -List $list -PageSize 50 
        foreach($item in $listItems)
        {
            if($list.BaseType -eq "GenericList")
            {
                $localurl = $tenantUrl + $item.FieldValues["FileDirRef"]+"/DispForm.aspx?ID=" + $item.id
            }
            elseif ($list.BaseType -eq "DocumentLibrary") 
            {
                
                $localurl = $tenantUrl+  $item.FieldValues["FileRef"] 
            
            }    
            #$results = Get-PnPSearchCrawlLog -Filter $localurl 
            
            if($results)
            {
                Write-Debug $localurl 
                $lastcrawled = Get-Date -AsUTC
                $lastcrawled = $lastcrawled.AddDays(-100)
                foreach($result in $results)  #not sure if the last in the array always is the most resent, hence the iteration
                {
                    if($result.crawltime -gt $lastcrawled)
                    {
                        $lastcrawled = $result.crawltime
                    }
                }
                $lastModified = $item.FieldValues["Modified"]
                if($lastcrawled -lt $lastModified)
                {
                    #the item has been modified and the crawler hasn't picked it up yet
                    Write-Host "Last crawled $lastcrawled , last updated $lastModified" -ForegroundColor Red
                }
            }
        }
    }
}
catch
{
    write-host $_.Exception.Message 
}
