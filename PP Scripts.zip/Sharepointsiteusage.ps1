# Connect to SharePoint Online
Connect-SPOService -url "https://reactllearning800-admin.sharepoint.com/"

#Get SharePoint Site Collection Usage
$siteCollections = Get-SPOSite -Limit All
$siteUsage = $siteCollections | Select-Object URL, Owner, StorageUsageCurrent, StorageQuota, LastContentModifiedDate

#Export to CSV
$siteUsage | Export-Csv -Path "C:\Users\ksingh318\OneDrive - DXC Production\Powershell\SharePointUsageReport.csv" -NoTypeInformation

Write-Host "Exported"
