# Connect to SharePoint Online site
Connect-PnPOnline -Url "https://reactllearning800.sharepoint.com/sites/teams/" -UseWebLogin
# List Alerts for a user
Write-Host "Listing all alerts for the current user..."
$alerts = Get-PnPAlert
$alerts | Format-Table -Property Title, User, AlertType, ListTitle, Id
# Create a new alert for a user
$listUrl = "/sites/teams/Lists/SharepointAlerts/"  # SharePoint list URL
$userEmail = "komalsingh@reactllearning800.onmicrosoft.com"  # Email of the user to receive the alert

Write-Host "Creating a new alert for user $userEmail..."
#Add-PnPAlert -List $listUrl -User $userEmail -ChangeType All -Frequency Daily
Add-PnPAlert -Title "Alert1" -List "SharepointAlerts" -User "i:0#.f|membership|komalsingh@reactllearning800.onmicrosoft.com"

Write-Host "Alert created successfully for user $userEmail."

# # Delete an alert by its ID
# $alertIdToDelete = 1  # Replace with the alert ID to delete
# Write-Host "Deleting alert with ID $alertIdToDelete..."
# Remove-PnPAlert -Identity $alertIdToDelete
# Write-Host "Alert with ID $alertIdToDelete has been deleted."

# Disconnect from SharePoint
Disconnect-PnPOnline
