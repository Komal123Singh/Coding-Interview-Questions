# Connect to SharePoint Online
Connect-PnPOnline -Url "https://reactllearning800.sharepoint.com/sites/teams/" -UseWebLogin

# Specify the list name
$listName = "Product"  # Replace with your list name

# Get items from the SharePoint list that are pending approval
$items = Get-PnPListItem -List $listName | Where-Object { $_["Status"] -eq "Pending" }
 Write-Host "Item with ID $items approved."
# Loop through each item
foreach ($item in $items) {
    # Condition to approve items (this can be modified based on your needs)
    if ($item["Title"] -eq "testApproval") {
        # Approve the item
        Set-PnPListItem -List $listName -Identity $item.Id -Values @{"Status" = "Approved"}
        Write-Host "Item with ID $($item.Id) approved."
    } else {
        # Optionally, reject the item if it doesn't meet the condition
        Set-PnPListItem -List $listName -Identity $item.Id -Values @{"Status" = "Rejected"}
        Write-Host "Item with ID $($item.Id) rejected."
    }
}
