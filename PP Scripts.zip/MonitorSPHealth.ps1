# Connect to SharePoint Online
Connect-PnPOnline -Url "https://reactllearning800.sharepoint.com/sites/teams" -UseWebLogin

$sites = Get-PnPTenantSite
# Loop through all sites
foreach ($site in $sites) {
    Write-Host "Checking $($site.Url)..."
    Write-Host "Status: $($site.Status)"
    Write-Host "Storage Usage: $($site.StorageUsageCurrent) MB"
    Write-Host "Last Modified: $($site.LastContentModifiedDate)"
}
