# Connect to SharePoint Online site
$siteUrl = "https://reactllearning800.sharepoint.com/sites/teams/"  # Replace with your SharePoint site URL
Connect-PnPOnline -Url $siteUrl -UseWebLogin

# Specify the SharePoint List name
$listName = "Spfxlist"  # Replace with your SharePoint list name

# Get the SharePoint List items
$listItems = Get-PnPListItem -List $listName

# Export the list items to a CSV file
$csvFilePath = "C:\Users\ksingh318\OneDrive - DXC Production\Powershell\CSVFile.csv"  # Specify the path where you want to save the CSV
$exportData = @()

# Iterate through each list item and create a custom object for each row of data
foreach ($item in $listItems) {
    $obj = New-Object PSObject
    # Loop through all fields in the current list item
    foreach ($field in $item.FieldValues.Keys) {
        # Add each field to the object as a new property
        $obj | Add-Member -MemberType NoteProperty -Name $field -Value $item.FieldValues[$field]
    }
    # Add the created object to the exportData collection
    $exportData += $obj
}

# Export all data to CSV
$exportData | Export-Csv -Path $csvFilePath -NoTypeInformation



Write-Host "List data has been successfully exported to $csvFilePath."

# Disconnect from SharePoint Online
Disconnect-PnPOnline
